"""
GoAnywhere package uploader — small internal web UI.

Sign in with GitLab (OIDC, identity only). Authorized users — members of the
packages project at >= MIN_ACCESS_LEVEL — can replace the 'gateway' / 'mft'
installer held in the GitLab generic package registry. The privileged
delete+upload runs with the app's OWN Maintainer token, never the user's.

All config comes from the environment (see .env.example). No secrets in code.
Run behind TLS (uvicorn --ssl-*), because the session cookie is https-only.
"""

import logging
import os

import requests
from authlib.integrations.starlette_client import OAuth
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.concurrency import run_in_threadpool
from starlette.middleware.sessions import SessionMiddleware

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("goa-uploader")

# ---- config from env -------------------------------------------------------
GITLAB_URL       = os.environ["GITLAB_URL"].rstrip("/")
PROJECT_ID       = os.environ["PROJECT_ID"]
APP_TOKEN        = os.environ["GITLAB_API_TOKEN"]          # Maintainer, api scope
CLIENT_ID        = os.environ["OAUTH_CLIENT_ID"]
CLIENT_SECRET    = os.environ["OAUTH_CLIENT_SECRET"]
APP_BASE_URL     = os.environ["APP_BASE_URL"].rstrip("/")  # e.g. https://host:8443
SESSION_SECRET   = os.environ["SESSION_SECRET"]
MIN_ACCESS_LEVEL = int(os.environ.get("MIN_ACCESS_LEVEL", "30"))  # 30 = Developer

# product -> (registry package name, stable filename)
PRODUCTS = {
    "gateway": ("gateway", "gagateway_linux_x64.sh"),
    "mft":     ("mft",     "ga_linux_x64.sh"),
}
PKG_VERSION  = "current"
API          = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}"
AUTH_HEADERS = {"PRIVATE-TOKEN": APP_TOKEN}

app = FastAPI(title="GoAnywhere Package Uploader")
# SameSite=Lax + https_only means a cross-site POST won't carry the session
# cookie, which covers CSRF for this internal tool.
app.add_middleware(
    SessionMiddleware, secret_key=SESSION_SECRET, https_only=True, same_site="lax"
)
templates = Jinja2Templates(directory="templates")

oauth = OAuth()
oauth.register(
    name="gitlab",
    server_metadata_url=f"{GITLAB_URL}/.well-known/openid-configuration",
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    client_kwargs={"scope": "openid profile email"},
)


# ---- GitLab helpers (blocking; called via run_in_threadpool) ---------------
def is_authorized(user_id: str) -> bool:
    """True if the user is a member of the packages project at >= MIN_ACCESS_LEVEL."""
    r = requests.get(f"{API}/members/all/{user_id}", headers=AUTH_HEADERS, timeout=15)
    if r.status_code == 404:
        return False
    r.raise_for_status()
    return r.json().get("access_level", 0) >= MIN_ACCESS_LEVEL


def _find_packages(pkg: str):
    """Generic packages whose name is EXACTLY pkg (the ?package_name filter is fuzzy)."""
    r = requests.get(
        f"{API}/packages",
        headers=AUTH_HEADERS,
        params={"package_name": pkg, "package_type": "generic", "per_page": 100},
        timeout=15,
    )
    r.raise_for_status()
    return [p for p in r.json() if p["name"] == pkg]


def current_packages():
    """{product: package_dict or None} for the status view."""
    out = {}
    for prod, (pkg, _dest) in PRODUCTS.items():
        matches = _find_packages(pkg)
        out[prod] = matches[0] if matches else None
    return out


def replace_package(product: str, upload: UploadFile):
    """Delete the existing package for this product, then upload the new file."""
    pkg, dest = PRODUCTS[product]

    for p in _find_packages(pkg):
        d = requests.delete(f"{API}/packages/{p['id']}", headers=AUTH_HEADERS, timeout=30)
        if d.status_code == 403:
            raise HTTPException(500, "App token lacks Maintainer role (cannot delete).")
        if d.status_code not in (200, 204):
            raise HTTPException(500, f"Delete failed (HTTP {d.status_code}).")

    upload.file.seek(0)
    url = f"{API}/packages/generic/{pkg}/{PKG_VERSION}/{dest}"
    u = requests.put(url, headers=AUTH_HEADERS, data=upload.file, timeout=600)
    if u.status_code != 201:
        raise HTTPException(500, f"Upload failed (HTTP {u.status_code}): {u.text[:200]}")


# ---- routes ----------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    user = request.session.get("user")
    packages = await run_in_threadpool(current_packages) if user else {}
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "user": user, "packages": packages, "products": list(PRODUCTS)},
    )


@app.get("/login")
async def login(request: Request):
    return await oauth.gitlab.authorize_redirect(request, f"{APP_BASE_URL}/auth/callback")


@app.get("/auth/callback")
async def callback(request: Request):
    token = await oauth.gitlab.authorize_access_token(request)
    claims = token.get("userinfo") or await oauth.gitlab.userinfo(token=token)
    user_id = str(claims["sub"])  # GitLab OIDC: sub == numeric user id

    if not await run_in_threadpool(is_authorized, user_id):
        request.session.clear()
        return HTMLResponse(
            "<h3>Not authorized</h3><p>You must be a member of the packages project.</p>",
            status_code=403,
        )

    request.session["user"] = {
        "id": user_id,
        "name": claims.get("name") or claims.get("preferred_username") or user_id,
    }
    return RedirectResponse("/", status_code=303)


@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=303)


@app.post("/upload")
async def upload(
    request: Request, product: str = Form(...), file: UploadFile = File(...)
):
    user = request.session.get("user")
    if not user:
        raise HTTPException(401, "Not logged in.")
    # re-check authorization on the action itself, not just at login
    if not await run_in_threadpool(is_authorized, user["id"]):
        raise HTTPException(403, "Not authorized.")
    if product not in PRODUCTS:
        raise HTTPException(400, "Unknown product.")
    if not file.filename.endswith(".sh"):
        raise HTTPException(400, "Expected a .sh installer.")

    log.info("upload: user=%s product=%s file=%s", user["name"], product, file.filename)
    await run_in_threadpool(replace_package, product, file)
    return RedirectResponse("/?ok=1", status_code=303)


@app.get("/healthz")
async def healthz():
    return {"ok": True}
