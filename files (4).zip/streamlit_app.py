"""
Resurfaced -- a pure-Python web app.

Finds and explains resurfaced (REOPENED) Tenable findings, prioritizes them by
real-world threat signals (CISA KEV, exploitability, EPSS), and -- optionally --
enriches each with its environment / location via Axonius. Exports a
Grafana-compatible findings CSV.

Run:
    pip install -r requirements.txt
    streamlit run streamlit_app.py

Reuses tenable_client.py, analysis.py, axonius_client.py. Env vars honoured:
    TIO_ACCESS_KEY / TIO_SECRET_KEY / TIO_BASE_URL
    AXONIUS_URL / AXONIUS_API_KEY / AXONIUS_API_SECRET
    DEMO_MODE=1
"""

import os
import datetime as dt

import pandas as pd
import streamlit as st
import plotly.graph_objects as go

from tenable_client import (TenableVMClient, TenableError, generate_demo_findings,
                            iter_resurfaced_from_ndjson)
import analysis
import axonius_client as ax

st.set_page_config(page_title="Resurfaced -- Tenable recurrence",
                   page_icon="\U0001F501", layout="wide")

REASON_STYLE = {
    "threat_priority": ("red", "Actively dangerous"),
    "asset_rebuild": ("blue", "Host rebuilt / restored"),
    "fleet_regression": ("red", "Fleet-wide regression"),
    "environment_cluster": ("violet", "Site-wide event"),
    "scan_flap": ("orange", "Scan inconsistency"),
    "true_regression": ("orange", "Genuine regression"),
    "uncategorized": ("gray", "Needs review"),
}
SEV_COLOR = {"critical": "red", "high": "orange", "medium": "orange",
             "low": "blue", "info": "gray"}

CSV_COLUMNS = [
    "snapshot_date", "finding_id", "asset_uuid", "hostname", "environment",
    "plugin_id", "plugin_name", "severity", "severity_rank", "state",
    "vpr_score", "epss_score", "on_cisa_kev", "exploit_available",
    "exploited_by_malware", "in_the_news", "has_patch", "unsupported_by_vendor",
    "cves", "first_found", "last_found", "last_fixed", "held_days",
    "reason", "risk_score",
]


# --------------------------------------------------------------------------- #
def run_scan(cfg, status):
    if cfg["demo"]:
        status.info("Demo mode: generating synthetic resurfaced findings...")
        raw = generate_demo_findings()
    elif cfg["source"] == "ndjson":
        raw = list(iter_resurfaced_from_ndjson(
            cfg["ndjson_path"], since_days=cfg["since_days"],
            severities=cfg["severities"], on_progress=lambda m: status.info(m)))
    else:
        client = TenableVMClient(cfg["tio_access"], cfg["tio_secret"],
                                 base_url=cfg["tio_base"])
        raw = list(client.iter_resurfaced(since_days=cfg["since_days"],
                                          severities=cfg["severities"],
                                          on_progress=lambda m: status.info(m)))
    rows = analysis.normalize(raw)

    # Optional Axonius enrichment.
    if cfg["demo"] and cfg["use_axonius"]:
        ax.enrich_rows(rows, ax.demo_indexes())
    elif cfg["use_axonius"]:
        status.info("Enriching with Axonius asset context...")
        client = ax.AxoniusClient(cfg["ax_url"], cfg["ax_key"], cfg["ax_secret"])
        assets = client.fetch_assets(on_progress=lambda m: status.info(m))
        ax.enrich_rows(rows, ax.build_indexes(assets))

    insights = analysis.infer_causes(rows)
    for r in rows:
        r["risk_score"] = round(analysis.risk_score(r), 1)
    summary = analysis.summarize(rows, insights)
    return {"rows": rows, "insights": insights, "summary": summary,
            "pulled_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def timeline_figure(row):
    def parse(s):
        try:
            return dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            return None

    first, fixed, found = parse(row["first_found"]), parse(row["last_fixed"]), parse(row["last_found"])
    if not first or not found:
        return None
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[first, found], y=[0, 0], mode="lines",
                             line=dict(color="#2b3040", width=6),
                             hoverinfo="skip", showlegend=False))
    if fixed:
        fig.add_trace(go.Scatter(x=[first, fixed], y=[0, 0], mode="lines",
                                 line=dict(color="#3fb6a8", width=6),
                                 hoverinfo="skip", showlegend=False))
        fig.add_trace(go.Scatter(x=[fixed, found], y=[0, 0], mode="lines",
                                 line=dict(color="#e8a33d", width=3, dash="dot"),
                                 hoverinfo="skip", showlegend=False))
        if row["held_days"] is not None:
            fig.add_annotation(x=fixed + (found - fixed) / 2, y=0.35,
                               text=f"fix held {row['held_days']}d",
                               showarrow=False, font=dict(color="#3fb6a8", size=12))
    nodes_x = [first] + ([fixed] if fixed else []) + [found]
    nodes_c = ["#7c8aa5"] + (["#3fb6a8"] if fixed else []) + ["#e8a33d"]
    nodes_t = (["first seen<br>" + first.strftime("%b %d")]
               + (["fixed<br>" + fixed.strftime("%b %d")] if fixed else [])
               + ["resurfaced<br>" + found.strftime("%b %d")])
    fig.add_trace(go.Scatter(x=nodes_x, y=[0] * len(nodes_x), mode="markers+text",
                             marker=dict(size=15, color=nodes_c,
                                         line=dict(color="#0e1420", width=2)),
                             text=nodes_t, textposition="bottom center",
                             textfont=dict(size=11, color="#c9d4e5"),
                             hoverinfo="x", showlegend=False))
    fig.update_layout(height=170, margin=dict(l=10, r=10, t=30, b=10),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      yaxis=dict(visible=False, range=[-0.8, 0.9]),
                      xaxis=dict(showgrid=False, color="#7c8aa5"))
    return fig


def threat_badges(r):
    b = []
    if r["on_cisa_kev"]:
        b.append(":red[**KEV**]")
    if r["exploited_by_malware"] or r["in_the_news"]:
        b.append(":red[in the wild]")
    if r["exploit_available"]:
        b.append(":orange[exploit avail]")
    return "  ".join(b)


# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
st.sidebar.title("\U0001F501 Resurfaced")
st.sidebar.caption("Why fixed vulnerabilities came back -- Tenable VM")

env_tio_k = os.environ.get("TIO_ACCESS_KEY", "") or os.environ.get("TENABLE_ACCESS_KEY", "")
env_tio_s = os.environ.get("TIO_SECRET_KEY", "") or os.environ.get("TENABLE_SECRET_KEY", "")
default_demo = os.environ.get("DEMO_MODE", "").lower() in ("1", "true", "yes") \
    or not (env_tio_k and env_tio_s)

demo = st.sidebar.checkbox("Use demo data (no API keys)", value=default_demo)

source = "api"
ndjson_path = os.environ.get("TIO_OUT_NDJSON", "/opt/tenable/vulnerabilities.ndjson")
tio_access = tio_secret = ""
tio_base = os.environ.get("TIO_BASE_URL", "https://cloud.tenable.com")
if not demo:
    source_label = st.sidebar.radio(
        "Data source", ["Tenable API", "NDJSON export file"],
        help="Read your existing export_vulns.py output instead of a fresh API pull.")
    source = "ndjson" if source_label == "NDJSON export file" else "api"
    if source == "ndjson":
        ndjson_path = st.sidebar.text_input("NDJSON path", value=ndjson_path)
    else:
        with st.sidebar.expander("Tenable credentials",
                                 expanded=not (env_tio_k and env_tio_s)):
            tio_access = st.text_input("TIO_ACCESS_KEY", value=env_tio_k, type="password")
            tio_secret = st.text_input("TIO_SECRET_KEY", value=env_tio_s, type="password")
            tio_base = st.text_input("TIO_BASE_URL", value=tio_base)

env_ax_url = os.environ.get("AXONIUS_URL", "")
env_ax_key = os.environ.get("AXONIUS_API_KEY", "")
env_ax_sec = os.environ.get("AXONIUS_API_SECRET", "")
use_axonius = st.sidebar.checkbox(
    "Enrich with Axonius (environment / location)",
    value=demo or bool(env_ax_key and env_ax_sec))
ax_url = ax_key = ax_secret = ""
if use_axonius and not demo:
    with st.sidebar.expander("Axonius credentials",
                             expanded=not (env_ax_key and env_ax_sec)):
        ax_url = st.text_input("AXONIUS_URL", value=env_ax_url)
        ax_key = st.text_input("AXONIUS_API_KEY", value=env_ax_key, type="password")
        ax_secret = st.text_input("AXONIUS_API_SECRET", value=env_ax_sec, type="password")

window = st.sidebar.selectbox("Window", [30, 90, 180, 365], index=1,
                              format_func=lambda d: f"Last {d} days")
min_sev = st.sidebar.selectbox("Minimum severity",
                               ["All", "Medium+", "High+", "Critical"], index=0)
sev_map = {"All": None, "Medium+": ["medium", "high", "critical"],
           "High+": ["high", "critical"], "Critical": ["critical"]}

if st.sidebar.button("Pull resurfaced findings", type="primary", use_container_width=True):
    status = st.sidebar.empty()
    cfg = {"demo": demo, "source": source, "ndjson_path": ndjson_path,
           "tio_access": tio_access, "tio_secret": tio_secret, "tio_base": tio_base,
           "since_days": window, "severities": sev_map[min_sev],
           "use_axonius": use_axonius, "ax_url": ax_url, "ax_key": ax_key,
           "ax_secret": ax_secret}
    try:
        with st.spinner("Pulling from Tenable..."):
            st.session_state.data = run_scan(cfg, status)
        status.success("Done.")
    except (TenableError, ax.AxoniusError) as e:
        st.session_state.data = None
        st.sidebar.error(f"API error:\n\n{e}")
    except Exception as e:  # noqa: BLE001
        st.session_state.data = None
        st.sidebar.error(f"Unexpected error:\n\n{e}")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
st.title("Resurfaced findings")
st.caption("A resurfaced finding is one Tenable marked *fixed* and then detected "
           "again (API state `REOPENED`).")

data = st.session_state.get("data")
if not data:
    st.info("Set your options in the sidebar and click **Pull resurfaced findings**. "
            "Leave *Use demo data* checked to try it without API keys.")
    st.stop()

rows, insights, summary = data["rows"], data["insights"], data["summary"]
st.caption(f"Pulled {data['pulled_at']}")

m = st.columns(6)
m[0].metric("Resurfaced", summary["total"])
m[1].metric("Affected hosts", summary["assets"])
m[2].metric("Critical", summary["critical"])
m[3].metric("High", summary["high"])
m[4].metric("On CISA KEV", summary["kev"])
m[5].metric("Actively exploitable", summary["exploitable"])

# CSV export (Grafana-compatible findings schema)
snap = dt.datetime.utcnow().strftime("%Y-%m-%d")
csv_rows = [{
    "snapshot_date": snap, "finding_id": r["finding_id"], "asset_uuid": r["asset_uuid"],
    "hostname": r["hostname"], "environment": r.get("environment", ""),
    "plugin_id": r["plugin_id"], "plugin_name": r["plugin_name"],
    "severity": r["severity"], "severity_rank": r["severity_rank"], "state": "REOPENED",
    "vpr_score": r["vpr"], "epss_score": r["epss"], "on_cisa_kev": r["on_cisa_kev"],
    "exploit_available": r["exploit_available"], "exploited_by_malware": r["exploited_by_malware"],
    "in_the_news": r["in_the_news"], "has_patch": r["has_patch"],
    "unsupported_by_vendor": r["unsupported_by_vendor"], "cves": ",".join(r["cves"]),
    "first_found": r["first_found"], "last_found": r["last_found"],
    "last_fixed": r["last_fixed"], "held_days": r["held_days"],
    "reason": r.get("reason", ""), "risk_score": r["risk_score"],
} for r in rows]
csv_df = pd.DataFrame(csv_rows, columns=CSV_COLUMNS)
st.download_button("Download findings CSV (Grafana schema)",
                   csv_df.to_csv(index=False).encode("utf-8"),
                   file_name=f"resurfaced_findings_{snap}.csv", mime="text/csv")

st.divider()

# insights
st.subheader("Likely causes")
st.caption("Ranked hypotheses inferred from how the findings returned, threat "
           "priority first.")
if not insights:
    st.write("No clear cross-cutting pattern -- each finding below returned on its own.")
for ins in insights:
    color, _ = REASON_STYLE.get(ins["kind"], ("gray", ins["kind"]))
    with st.container(border=True):
        st.markdown(f"**:{color}[{ins['title']}]**")
        st.write(ins["detail"])
        st.markdown(f":green[**What to check:** {ins['recommendation']}]")
        ev = ins.get("evidence", {})
        chips = []
        for k in ("host", "environment", "when"):
            if ev.get(k):
                chips.append(str(ev[k]))
        if ev.get("count"):
            chips.append(f"{ev['count']} findings")
        if ev.get("hosts"):
            chips.append(f"{ev['hosts']} hosts")
        chips += list(ev.get("cves", []))[:4]
        if ev.get("breakdown"):
            chips += [f"{k}:{v}" for k, v in ev["breakdown"].items()]
        if chips:
            st.caption(" &nbsp;|&nbsp; ".join(f"`{c}`" for c in chips))

st.divider()

# findings
st.subheader("Resurfaced findings")
fcol1, fcol2 = st.columns([3, 1])
query = fcol1.text_input("Filter", placeholder="host, plugin, CVE, environment...",
                         label_visibility="collapsed")
sort_by = fcol2.selectbox("Sort", ["Risk (KEV/exploit first)", "Severity",
                                    "Fix held (shortest)", "Most recent", "Host"],
                          label_visibility="collapsed")

view = rows
if query:
    q = query.lower()
    view = [r for r in view if q in
            (r["hostname"] + " " + r["plugin_name"] + " " + " ".join(r["cves"])
             + " " + r["ipv4"] + " " + str(r.get("environment", ""))).lower()]

big = float("inf")
sorters = {
    "Risk (KEV/exploit first)": lambda r: -analysis.risk_score(r),
    "Severity": lambda r: (-r["severity_rank"],
                           r["held_days"] if r["held_days"] is not None else big),
    "Fix held (shortest)": lambda r: r["held_days"] if r["held_days"] is not None else big,
    "Most recent": lambda r: r["last_found"] or "",
    "Host": lambda r: r["hostname"],
}
view = sorted(view, key=sorters[sort_by], reverse=(sort_by == "Most recent"))

st.caption(f"{len(view)} finding(s)")
for r in view:
    sev_c = SEV_COLOR.get(r["severity"], "gray")
    reason_c, reason_label = REASON_STYLE.get(r.get("reason", "uncategorized"),
                                              ("gray", "Needs review"))
    cve = f" &middot; `{r['cves'][0]}`" if r["cves"] else ""
    env = f"  \u00b7  `{r['environment']}`" if r.get("environment") else ""
    badges = threat_badges(r)
    badges = ("  " + badges) if badges else ""
    label = (f":{sev_c}[**{r['severity'].upper()}**]  {r['plugin_name']}{cve}"
             f"  \u2014  `{r['hostname']}`{env}  \u00b7  :{reason_c}[{reason_label}]{badges}")
    with st.expander(label):
        fig = timeline_figure(r)
        if fig:
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar": False},
                            key=f"tl_{r['asset_id']}_{r['plugin_id']}")
        meta = {
            "Host": f"{r['hostname']} ({r['fqdn']})" if r["fqdn"] else r["hostname"],
            "Environment": r.get("environment") or "-",
            "IPv4": r["ipv4"] or "-",
            "OS": r["os"] or "unknown",
            "CVEs": ", ".join(r["cves"]) or "-",
            "VPR / EPSS": f"{r['vpr']} / {r['epss']}",
            "CISA KEV": "yes" if r["on_cisa_kev"] else "no",
            "Exploit": ("in the wild" if (r["exploited_by_malware"] or r["in_the_news"])
                        else "available" if r["exploit_available"] else "none known"),
            "Patch available": "yes" if r["has_patch"] else "no",
            "First found": r["first_found"],
            "Last fixed": r["last_fixed"],
            "Resurfaced": r["last_found"],
            "Fix held": f"{r['held_days']} days" if r["held_days"] is not None else "-",
        }
        left, right = st.columns(2)
        items = list(meta.items())
        half = (len(items) + 1) // 2
        for col, chunk in ((left, items[:half]), (right, items[half:])):
            with col:
                for k, v in chunk:
                    st.markdown(f"**{k}:** `{v}`")
        if r["output"]:
            st.markdown("**Scanner output**")
            st.code(r["output"], language="text")
