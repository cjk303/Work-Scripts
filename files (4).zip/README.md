# Resurfaced

A pure-Python web app that connects to **Tenable Vulnerability Management**
(cloud), pulls the vulnerabilities that were fixed and then detected again,
explains **why they came back**, prioritizes them by **real-world threat**
(CISA KEV, exploitability, EPSS), and — optionally — tags each with its
**environment / location** via **Axonius**.

In the Tenable UI these are *Resurfaced* findings; in the API they're the
`REOPENED` state. That mapping is the basis of the tool.

It's shaped to fit an existing Axonius + Tenable + Grafana pipeline: same
`TIO_*` / `AXONIUS_*` env vars, the same `X-ApiKeys` header format, gzip'd
octet-stream chunk handling, and the same rich threat fields — plus a CSV export
in a Grafana-friendly findings schema.

## Run it (pure Python — recommended)

The whole app, UI included, is Python via Streamlit. No HTML/JS to touch.

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

Leave **Use demo data** checked to try it with no keys (the demo set exercises
every pattern, threat flag, and environment). Otherwise uncheck it and either set
the env vars below or paste keys into the sidebar, then click **Pull resurfaced
findings**.

Environment variables honoured:

```
TIO_ACCESS_KEY / TIO_SECRET_KEY / TIO_BASE_URL      # Tenable (required for live)
TIO_NUM_ASSETS / TIO_POLL_INTERVAL / TIO_TIMEOUT    # export tuning (low-RAM: small NUM_ASSETS)
TIO_OUT_NDJSON                                      # default NDJSON path
AXONIUS_URL / AXONIUS_API_KEY / AXONIUS_API_SECRET  # optional enrichment
DEMO_MODE=1                                         # synthetic data
```

### Two data sources

In the sidebar (live mode) you can choose where findings come from:

- **Tenable API** — a fresh `state = REOPENED` export, filtered by `resurfaced_date`.
- **NDJSON export file** — reads an existing `vulnerabilities.ndjson` (e.g. the
  output of the scheduled `export_vulns.py`) and filters it to REOPENED locally.
  This reuses an export you already generate on a resumable schedule and avoids a
  second API pull competing for Tenable's export-concurrency limits. Point it at
  the file (default `/opt/tenable/vulnerabilities.ndjson`) and go.

Chunk decoding is hardened the same way as those exporters: it checks for
JSON-looking content before attempting to gunzip, so it works whether or not the
HTTP layer already decompressed the body.

## What it does

1. Starts an async **vulnerability export** filtered to `state = REOPENED` and
   `resurfaced_date >= <window>`, polls it, and downloads the (possibly gzipped)
   chunks.
2. Extracts the rich per-finding fields: severity, VPR, EPSS, `on_cisa_kev`,
   `exploit_available`, `exploited_by_malware`, `in_the_news`, `has_patch`,
   `unsupported_by_vendor`, and the fix/resurface timestamps.
3. **Prioritizes.** A resurfaced KEV / exploited-in-the-wild vulnerability is a
   very different problem from a resurfaced legacy-TLS check. The first insight
   card always surfaces the actively-dangerous set, and a risk score floats them
   to the top of the table.
4. **Explains.** It clusters the findings into ranked hypotheses:
   - **Host rebuilt / restored** — many unrelated findings resurface on one host
     together.
   - **Fleet-wide regression** — one plugin resurfaces across many hosts at once
     (rolled-back superseding patch, config drift, base-image change).
   - **Site-wide event** — resurfacing concentrates in one Axonius environment
     (needs enrichment on).
   - **Scan inconsistency** — a fix that reverted within ~3 days.
   - **Genuine regression** — a fix that held 60+ days then broke.
5. **Enriches (optional).** With Axonius on, each finding is matched to its asset
   via tiered UUID → FQDN → short-hostname → IP matching (the same approach as
   the production exporter) and tagged with its environment / location.
6. **Visualizes.** Each finding expands to a **resurfacing timeline**
   (first-seen → last-fixed → resurfaced) so you can see how long the fix held,
   plus the scanner output that is the actual evidence — all drawn with Plotly,
   still pure Python.
7. **Exports.** One click downloads a findings CSV (snapshot date, finding_id,
   asset, environment, threat flags, timestamps, inferred reason, risk score) for
   Grafana or diffing between runs.

## Files

| File | Purpose |
|------|---------|
| `streamlit_app.py` | **Pure-Python web app** (Streamlit). The recommended entry point. |
| `tenable_client.py` | `TenableVMClient` — export lifecycle, gzip/octet-stream chunks; + demo generator |
| `axonius_client.py` | Optional Axonius fetch + tiered asset matching / enrichment |
| `analysis.py` | Normalization, threat prioritization, cause inference, risk scoring |
| `.streamlit/config.toml` | Dark theme for the Streamlit app |
| `app.py`, `templates/`, `static/` | The alternative Flask + HTML/JS build |

## Also included: a Flask + HTML/JS version

`app.py` is a Flask build of the same core (shares `tenable_client.py` and
`analysis.py`, so the integration and cause inference are identical):

```bash
DEMO_MODE=1 python app.py      # or export the TIO_* keys
# open http://127.0.0.1:5000
```

The Flask UI predates the Axonius/threat additions and surfaces the core
resurfacing analysis; the Streamlit app is the fuller one.

## Notes

- **Async by design.** The export returns a UUID, then you poll for chunks.
  Streamlit runs the loop inline; the Flask version uses a background thread.
- **Cause labels are hypotheses, not verdicts** — each insight says what to
  check. Thresholds (4+ findings/host, 5+ hosts/plugin, 3-day flap, 60-day
  dormancy, environment concentration) live at the top of the functions in
  `analysis.py`.
- **Tenable VM (cloud) only.** For **Tenable.sc** on-prem the API differs (token
  auth, recurrence filter instead of a `state` export); `analysis.py` is
  reusable, only `tenable_client.py` would be swapped.
- **VPR v2 transition** (effective July 1, 2026): the record reads `vpr` and
  `vpr_v2` defensively, and `on_cisa_kev` is read from `vpr_v2`, matching the
  production exporter. If you add a VPR filter to the export, use `vpr_score`.
