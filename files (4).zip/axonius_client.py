"""
Optional Axonius enrichment.

Ports the tiered asset-matching approach from the production exporter so each
resurfaced Tenable finding can be tagged with its environment / location and
asset context. Matching tiers (first hit wins):

    1. Tenable asset UUID  == Axonius tenable_io_adapter uuid/id
    2. FQDN                 (case-insensitive, exact)
    3. Short hostname       (domain stripped)
    4. IPv4                 (unique only)

If no Axonius credentials are configured the rest of the tool works fine; the
environment column simply stays blank.

Env vars: AXONIUS_URL, AXONIUS_API_KEY, AXONIUS_API_SECRET.
"""

import re
from collections import defaultdict

import requests

UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")

AX_FIELDS = [
    "specific_data.data.name",
    "specific_data.data.hostname_preferred",
    "specific_data.data.os.type",
    "specific_data.data.network_interfaces.ips_v4_preferred",
    "adapters_data.gui.custom_location",
    "adapters_data.tenable_io_adapter.uuid",
    "adapters_data.tenable_io_adapter.id",
]

# Same AQL intent as the production exporter: real assets, exclude appliances.
AQL_QUERY = (
    'not ("adapters_data.gui.custom_appliance" == regex("yes", "i"))'
)


class AxoniusError(Exception):
    pass


def _flatten(val):
    if val is None:
        return ""
    if isinstance(val, list):
        return ", ".join(str(x) for x in val if x is not None)
    return str(val)


def _short(hostname):
    if not hostname:
        return ""
    h = hostname.strip().lower()
    dot = h.find(".")
    return h[:dot] if dot > 0 else h


def _fqdn(hostname):
    return hostname.strip().lower() if hostname else ""


def _ips(raw):
    if not raw:
        return set()
    if isinstance(raw, list):
        raw = ", ".join(str(x) for x in raw if x)
    out = set()
    for part in re.split(r"[,\s]+", str(raw).strip().strip("[]")):
        part = part.strip().strip("'\"")
        if IP_RE.match(part):
            out.add(part)
    return out


def _norm_env(raw):
    loc = _flatten(raw).strip().upper()
    if not loc:
        return "UNKNOWN"
    return loc.split(",")[0].strip() if "," in loc else loc


class AxoniusClient:
    def __init__(self, url, api_key, api_secret, timeout=300):
        if not (url and api_key and api_secret):
            raise AxoniusError("Missing Axonius URL / key / secret.")
        self.url = url.rstrip("/")
        self.timeout = timeout
        self.headers = {
            "api-key": api_key, "api-secret": api_secret,
            "Content-Type": "application/json", "Accept": "application/json",
        }

    def fetch_assets(self, on_progress=None):
        endpoint = f"{self.url}/api/v2/assets/devices"
        assets, offset = [], 0
        while True:
            body = {"query": AQL_QUERY, "fields": AX_FIELDS,
                    "include_metadata": True,
                    "page": {"offset": offset, "limit": 2000}}
            resp = requests.post(endpoint, headers=self.headers, json=body,
                                 timeout=self.timeout)
            if resp.status_code >= 400:
                raise AxoniusError(f"{resp.status_code}: {resp.text[:200]}")
            data = resp.json()
            batch = data.get("assets", data.get("data", []))
            assets.extend(batch)
            total = data.get("meta", {}).get("page", {}).get("totalResources", len(assets))
            if on_progress:
                on_progress(f"Axonius: {len(assets)}/{total} assets")
            if len(assets) >= total or not batch:
                break
            offset += 2000
        return assets


def _asset_uuids(a):
    uuids = set()
    for key in ("adapters_data.tenable_io_adapter.uuid",
                "adapters_data.tenable_io_adapter.id"):
        val = a.get(key)
        vals = val if isinstance(val, list) else [val]
        for v in vals:
            if isinstance(v, str):
                m = UUID_RE.search(v)
                if m:
                    uuids.add(m.group().lower())
    return uuids


def build_indexes(assets):
    """Reverse indexes for matching a Tenable finding's asset to Axonius."""
    by_uuid, by_fqdn, by_short, by_ip = {}, defaultdict(list), defaultdict(list), defaultdict(list)
    for a in assets:
        hostname = a.get("specific_data.data.hostname_preferred", "") or ""
        info = {
            "environment": _norm_env(a.get("adapters_data.gui.custom_location")),
            "asset_name": _flatten(a.get("specific_data.data.name")),
        }
        for u in _asset_uuids(a):
            by_uuid[u] = info
        if _fqdn(hostname):
            by_fqdn[_fqdn(hostname)].append(info)
        if _short(hostname):
            by_short[_short(hostname)].append(info)
        for ip in _ips(a.get("specific_data.data.network_interfaces.ips_v4_preferred")):
            by_ip[ip].append(info)
    return {"uuid": by_uuid, "fqdn": dict(by_fqdn),
            "short": dict(by_short), "ip": dict(by_ip)}


def enrich_rows(rows, indexes):
    """Attach environment / asset_name / join_method to each finding row."""
    stats = defaultdict(int)
    for r in rows:
        info, method = None, ""
        u = r.get("asset_uuid", "")
        if u and u in indexes["uuid"]:
            info, method = indexes["uuid"][u], "uuid"
        if not info:
            cand = indexes["fqdn"].get(_fqdn(r.get("fqdn") or r.get("hostname")))
            if cand and len(cand) == 1:
                info, method = cand[0], "fqdn"
        if not info:
            cand = indexes["short"].get(_short(r.get("hostname")))
            if cand and len(cand) == 1:
                info, method = cand[0], "short"
        if not info:
            cand = indexes["ip"].get((r.get("ipv4") or "").strip())
            if cand and len(cand) == 1:
                info, method = cand[0], "ip"
        if info:
            r["environment"] = info["environment"]
            r["asset_name"] = info["asset_name"]
            r["join_method"] = method
            stats[method] += 1
        else:
            stats["unmatched"] += 1
    return dict(stats)


# --------------------------------------------------------------------------- #
# Demo index so the environment features are visible without live Axonius.
# --------------------------------------------------------------------------- #
def demo_indexes():
    def entry(env):
        return {"environment": env, "asset_name": ""}
    by_uuid = {}
    by_uuid.update({f"bb22-winfs{i:02d}": entry("DALLAS") for i in range(14)})
    by_uuid.update({
        "aa11-web04": entry("WARSAW"),
        "cc33-db02": entry("LONDON"),
        "dd44-app01": entry("WARSAW"),
        "ee55-vpn01": entry("NEW_YORK"),
    })
    return {"uuid": by_uuid, "fqdn": {}, "short": {}, "ip": {}}
