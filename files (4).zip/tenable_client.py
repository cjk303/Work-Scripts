"""
Tenable Vulnerability Management (cloud) API client.

Pulls REOPENED findings (the API name for what the UI calls "Resurfaced") via
the asynchronous vulnerability export endpoints, and extracts the same rich
threat-context fields used in the production Axonius/Tenable exporter this tool
was modelled on (KEV, exploitability, EPSS, VPR, patch availability, etc.).

Export lifecycle:
    1. POST /vulns/export                     -> export_uuid
    2. GET  /vulns/export/<uuid>/status       -> poll until FINISHED
    3. GET  /vulns/export/<uuid>/chunks/<id>  -> download each chunk

Chunks may arrive gzip-compressed and are requested as octet-stream, matching
Tenable's real behaviour.

Auth header:
    X-ApiKeys: accessKey=<ACCESS_KEY>; secretKey=<SECRET_KEY>
"""

import os
import json
import gzip
import time
import random
import datetime as dt
from typing import Callable, Iterable, Optional

import requests

CLOUD_BASE = "https://cloud.tenable.com"

# Tunable knobs (same env vars as the production exporters). Low-RAM hosts
# should keep NUM_ASSETS small; vuln-export chunks are sized by asset count.
NUM_ASSETS = int(os.getenv("TIO_NUM_ASSETS", "200"))
POLL_INTERVAL = int(os.getenv("TIO_POLL_INTERVAL", "5"))
TIMEOUT = int(os.getenv("TIO_TIMEOUT", "120"))


def decode_chunk_bytes(raw: bytes) -> str:
    """
    Robustly decode a Tenable export chunk body.

    requests / urllib3 may already have decompressed a gzip response, so the
    bytes could be raw JSON OR still-gzipped. Check for JSON-looking content
    first, only gunzip on the gzip magic bytes, and fall back to plain decode.
    (Same defensive approach as the export_assets.py / export_vulns.py scripts.)
    """
    if not raw:
        return ""
    stripped = raw.lstrip()
    if stripped[:1] in (b"[", b"{"):
        return raw.decode("utf-8", errors="replace")
    if raw[:2] == b"\x1f\x8b":
        return gzip.decompress(raw).decode("utf-8", errors="replace")
    return raw.decode("utf-8", errors="replace")


def parse_chunk_json(text: str) -> list:
    """A chunk is normally a JSON array; tolerate a dict wrapper too."""
    text = text.strip()
    if not text:
        return []
    obj = json.loads(text)
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for key in ("assets", "data", "items", "results", "vulnerabilities"):
            if isinstance(obj.get(key), list):
                return obj[key]
        return [obj]
    return []


class TenableError(Exception):
    pass


class TenableVMClient:
    def __init__(self, access_key: str, secret_key: str, base_url: str = CLOUD_BASE,
                 timeout: int = TIMEOUT):
        if not access_key or not secret_key:
            raise TenableError("Missing Tenable access/secret key.")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.access_key = access_key
        self.secret_key = secret_key
        self.session = requests.Session()

    def _hdr(self, accept="application/json"):
        return {
            "Accept": accept,
            "Content-Type": "application/json",
            "X-ApiKeys": f"accessKey={self.access_key}; secretKey={self.secret_key}",
            "User-Agent": "resurfaced-vuln-dashboard/2.0",
        }

    # -- low level ---------------------------------------------------------

    def _request(self, method: str, path: str, **kw):
        url = f"{self.base_url}{path}"
        for attempt in range(5):
            resp = self.session.request(method, url, headers=self._hdr(),
                                        timeout=self.timeout, **kw)
            if resp.status_code == 429:
                wait = int(resp.headers.get("retry-after", 2 ** attempt))
                time.sleep(min(wait, 30))
                continue
            if resp.status_code >= 400:
                raise TenableError(
                    f"{method} {path} -> {resp.status_code}: {resp.text[:300]}")
            return resp
        raise TenableError(f"{method} {path} kept returning 429 (rate limited).")

    # -- export lifecycle --------------------------------------------------

    def start_resurfaced_export(self, since_days: int = 90, severities: Optional[list] = None,
                                num_assets: int = NUM_ASSETS) -> str:
        since_ts = int((dt.datetime.now(dt.timezone.utc)
                        - dt.timedelta(days=since_days)).timestamp())
        filters = {"state": ["REOPENED"], "resurfaced_date": since_ts}
        if severities:
            filters["severity"] = severities
        body = {"num_assets": num_assets, "filters": filters}
        data = self._request("POST", "/vulns/export", json=body).json()
        export_uuid = data.get("export_uuid")
        if not export_uuid:
            raise TenableError(f"No export_uuid in response: {data}")
        return export_uuid

    def get_status(self, export_uuid: str) -> dict:
        return self._request("GET", f"/vulns/export/{export_uuid}/status").json()

    def get_chunk(self, export_uuid: str, chunk_id) -> list:
        """Download one chunk. Chunks come as octet-stream and may be gzipped."""
        url = f"{self.base_url}/vulns/export/{export_uuid}/chunks/{chunk_id}"
        for attempt in range(5):
            resp = self.session.get(url, headers=self._hdr("application/octet-stream"),
                                    timeout=self.timeout)
            if resp.status_code == 429:
                time.sleep(min(int(resp.headers.get("retry-after", 2 ** attempt)), 30))
                continue
            if resp.status_code >= 400:
                raise TenableError(f"chunk {chunk_id} -> {resp.status_code}: {resp.text[:200]}")
            return parse_chunk_json(decode_chunk_bytes(resp.content))
        raise TenableError(f"chunk {chunk_id} kept returning 429.")

    def iter_resurfaced(self, since_days: int = 90, severities: Optional[list] = None,
                        on_progress: Optional[Callable[[str], None]] = None,
                        poll_interval: int = POLL_INTERVAL, max_wait: int = 900) -> Iterable[dict]:
        def note(msg):
            if on_progress:
                on_progress(msg)

        note("Requesting resurfaced-vulnerability export...")
        export_uuid = self.start_resurfaced_export(since_days, severities)
        note(f"Export queued ({export_uuid[:8]}). Waiting for chunks...")

        seen = set()
        deadline = time.time() + max_wait
        while True:
            status = self.get_status(export_uuid)
            state = status.get("status", "UNKNOWN")
            available = status.get("chunks_available", []) or []
            for chunk_id in available:
                if chunk_id in seen:
                    continue
                seen.add(chunk_id)
                note(f"Downloading chunk {chunk_id}...")
                for finding in self.get_chunk(export_uuid, chunk_id):
                    yield finding
            if state == "FINISHED" and len(seen) >= len(available):
                note("Export finished.")
                return
            if state in ("ERROR", "FAILED", "CANCELLED"):
                raise TenableError(f"Export ended in state {state}.")
            if time.time() > deadline:
                raise TenableError("Timed out waiting for export to finish.")
            time.sleep(poll_interval)


# ---------------------------------------------------------------------------
# Read from an existing NDJSON export (e.g. the export_vulns.py output,
# vulnerabilities.ndjson) instead of hitting the API. Each line is a raw
# Tenable finding record, so we just keep the REOPENED ones in the window.
# This avoids a second API pull and competing for Tenable's export concurrency.
# ---------------------------------------------------------------------------

def iter_resurfaced_from_ndjson(path: str, since_days: int = 90,
                                severities: Optional[list] = None,
                                on_progress: Optional[Callable[[str], None]] = None
                                ) -> Iterable[dict]:
    if not os.path.exists(path):
        raise TenableError(f"NDJSON file not found: {path}")
    cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=since_days)
    sev_set = set(s.lower() for s in severities) if severities else None
    kept = scanned = 0
    if on_progress:
        on_progress(f"Reading {os.path.basename(path)}...")

    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            scanned += 1
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (rec.get("state") or "").upper() != "REOPENED":
                continue
            if sev_set and str(rec.get("severity", "")).lower() not in sev_set:
                continue
            lf = rec.get("last_found")
            if lf:
                try:
                    if dt.datetime.fromisoformat(lf.replace("Z", "+00:00")) < cutoff:
                        continue
                except (ValueError, AttributeError):
                    pass
            kept += 1
            yield rec
            if on_progress and scanned % 20000 == 0:
                on_progress(f"Scanned {scanned:,} records, kept {kept:,} resurfaced...")

    if on_progress:
        on_progress(f"Kept {kept:,} resurfaced of {scanned:,} records.")


# ---------------------------------------------------------------------------
# Demo data: synthetic REOPENED findings shaped like the real export (rich
# threat fields included) so the UI works without live keys. Set DEMO_MODE=1.
# ---------------------------------------------------------------------------

def _ts(days_ago: float) -> str:
    return (dt.datetime.now(dt.timezone.utc)
            - dt.timedelta(days=days_ago)).strftime("%Y-%m-%dT%H:%M:%SZ")


def generate_demo_findings() -> list:
    findings = []
    fid = [1000]

    def add(asset, pid, name, cves, sev, vpr, first, fixed, found, output, threat=None):
        fid[0] += 1
        findings.append(_mk(fid[0], asset, pid, name, cves, sev, vpr,
                            first, fixed, found, output, threat or {}))

    # Pattern 1: host reimaged from an old snapshot -> burst on one host.
    reimage = {"fqdn": "web-prod-04.corp.local", "hostname": "web-prod-04",
               "ipv4": "10.20.4.14", "uuid": "aa11-web04",
               "operating_system": ["Ubuntu 22.04"]}
    for pid, name, cves, sev, vpr, thr in [
        (179234, "OpenSSL 3.0.x < 3.0.14 Multiple Vulnerabilities", ["CVE-2024-4741"], 3, 7.4, {"has_patch": True, "epss": 0.12}),
        (168746, "nginx < 1.25.3 Vulnerability", ["CVE-2023-44487"], 3, 7.5, {"has_patch": True, "exploit_available": True, "epss": 0.61}),
        (156103, "curl < 8.4.0 Heap Buffer Overflow", ["CVE-2023-38545"], 4, 9.8, {"has_patch": True, "exploit_available": True, "epss": 0.44}),
        (188221, "Python 3.10.x < 3.10.14 Vulnerability", ["CVE-2024-0450"], 2, 6.5, {"has_patch": True, "epss": 0.04}),
        (177451, "OpenSSH < 9.6 Multiple Vulnerabilities", ["CVE-2023-48795"], 3, 7.5, {"has_patch": True, "epss": 0.22}),
        (192004, "libxml2 < 2.11.7 Vulnerability", ["CVE-2024-25062"], 3, 7.5, {"has_patch": True, "epss": 0.08}),
    ]:
        add(reimage, pid, name, cves, sev, vpr, 61, 34, 2.0 + random.random() * 0.1,
            f"Installed version predates the fixed release for {cves[0]}.", thr)

    # Pattern 2: one plugin (a Windows cumulative update) regresses fleet-wide.
    for i in range(14):
        host = {"fqdn": f"win-fs-{i:02d}.corp.local", "hostname": f"win-fs-{i:02d}",
                "ipv4": f"10.30.1.{20 + i}", "uuid": f"bb22-winfs{i:02d}",
                "operating_system": ["Windows Server 2019"]}
        add(host, 205117, "KB5040437: Windows 10 / Server Security Update",
            ["CVE-2024-38063"], 4, 9.1, 48, 20, 3.0 + random.random() * 0.2,
            "Cumulative update KB5040437 is missing. Superseding update appears "
            "to have been rolled back by WSUS approval change.",
            {"has_patch": True, "on_cisa_kev": True, "exploit_available": True, "epss": 0.83})

    # Pattern 3: flapping -- fixed and found again within hours.
    flap = {"fqdn": "db-report-02.corp.local", "hostname": "db-report-02",
            "ipv4": "10.40.2.9", "uuid": "cc33-db02", "operating_system": ["RHEL 8.9"]}
    add(flap, 143122, "PostgreSQL < 15.6 Multiple Vulnerabilities", ["CVE-2024-0985"],
        3, 7.1, 40, 1.2, 1.0,
        "Detected on credentialed scan; absent on prior uncredentialed scan. "
        "Version query returned 15.4.", {"has_patch": True, "epss": 0.03})

    # Pattern 4: genuine long-dormant regression -- KEV, exploited in the wild.
    app = {"fqdn": "int-app-01.corp.local", "hostname": "int-app-01",
           "ipv4": "10.50.0.7", "uuid": "dd44-app01", "operating_system": ["Ubuntu 20.04"]}
    add(app, 156032, "Apache Log4j 1.x / 2.x Multiple Vulnerabilities (Log4Shell)",
        ["CVE-2021-44228"], 4, 10.0, 210, 150, 1.0,
        "Vulnerable log4j-core-2.14.1.jar found under /opt/int-app/lib. "
        "A redeploy reintroduced a pinned dependency.",
        {"has_patch": True, "on_cisa_kev": True, "exploit_available": True,
         "exploited_by_malware": True, "in_the_news": True, "epss": 0.95})

    # Standalone medium.
    vpn = {"fqdn": "vpn-gw-01.corp.local", "hostname": "vpn-gw-01",
           "ipv4": "10.10.0.2", "uuid": "ee55-vpn01", "operating_system": ["FortiOS 7.2"]}
    add(vpn, 176489, "TLS Version 1.0 / 1.1 Protocol Detection", [], 2, 4.3,
        90, 25, 5.0, "Legacy TLS re-enabled after a config restore.",
        {"has_patch": False, "epss": 0.0})

    return findings


def _mk(finding_id, asset, plugin_id, plugin_name, cves, severity, vpr,
        first_found, last_fixed, last_found, output, threat):
    sev_names = {0: "info", 1: "low", 2: "medium", 3: "high", 4: "critical"}
    return {
        "finding_id": f"demo-{finding_id}",
        "asset": asset,
        "plugin": {
            "id": plugin_id,
            "name": plugin_name,
            "family": "General",
            "cve": cves,
            "cvss3_base_score": vpr,
            "epss_score": threat.get("epss"),
            "exploit_available": threat.get("exploit_available", False),
            "exploited_by_malware": threat.get("exploited_by_malware", False),
            "in_the_news": threat.get("in_the_news", False),
            "has_patch": threat.get("has_patch", False),
            "unsupported_by_vendor": threat.get("unsupported_by_vendor", False),
            "vpr": {"score": vpr},
            "vpr_v2": {"score": vpr, "on_cisa_kev": threat.get("on_cisa_kev", False)},
        },
        "severity": sev_names[severity],
        "severity_id": severity,
        "state": "REOPENED",
        "first_found": _ts(first_found),
        "last_found": _ts(last_found),
        "last_fixed": _ts(last_fixed),
        "output": output,
    }
