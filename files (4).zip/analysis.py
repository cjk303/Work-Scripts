"""
Turn REOPENED (resurfaced) findings into an explanation of *why* they came back
and *which ones matter most*.

Tenable reports that a finding resurfaced but not the root cause. We infer likely
causes from patterns in the data, and we use the threat-context fields (CISA KEV,
exploitability, EPSS, patch availability) to rank the resurfaced findings by real
risk -- a resurfaced KEV/exploited vulnerability is a very different problem from a
resurfaced legacy-TLS check.

Optional Axonius enrichment (see axonius_client.py) attaches an environment /
location to each finding, which lets us flag when resurfacing concentrates in one
site (a strong signal of a site-wide reimage or restore).
"""

import datetime as dt
from collections import defaultdict

SEV_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def _parse(ts):
    if not ts:
        return None
    try:
        return dt.datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def normalize(raw: list) -> list:
    """Flatten Tenable finding objects into flat rows, including threat context."""
    rows = []
    for f in raw:
        asset = f.get("asset", {}) or {}
        plugin = f.get("plugin", {}) or {}
        vpr = plugin.get("vpr") or {}
        vpr_v2 = plugin.get("vpr_v2") or {}

        first_found = _parse(f.get("first_found"))
        last_found = _parse(f.get("last_found"))
        last_fixed = _parse(f.get("last_fixed"))
        held_days = None
        if last_fixed and last_found and last_found > last_fixed:
            held_days = round((last_found - last_fixed).total_seconds() / 86400, 1)

        vpr_score = vpr.get("score")
        if vpr_score is None:
            vpr_score = vpr_v2.get("score", plugin.get("cvss3_base_score"))

        kev = bool(vpr_v2.get("on_cisa_kev", False))
        exploit_available = bool(plugin.get("exploit_available", False))
        exploited = bool(plugin.get("exploited_by_malware", False))
        in_news = bool(plugin.get("in_the_news", False))
        actively_dangerous = kev or exploit_available or exploited or in_news

        rows.append({
            "finding_id": f.get("finding_id", ""),
            "asset_id": asset.get("uuid") or asset.get("hostname") or "unknown",
            "asset_uuid": (asset.get("uuid") or "").lower(),
            "hostname": asset.get("hostname") or asset.get("fqdn") or "unknown",
            "fqdn": asset.get("fqdn", ""),
            "ipv4": asset.get("ipv4", ""),
            "os": (asset.get("operating_system") or [""])[0],
            # environment / asset context filled in by axonius enrichment (optional)
            "environment": f.get("environment", ""),
            "asset_name": f.get("asset_name", ""),
            "join_method": f.get("join_method", ""),
            "plugin_id": plugin.get("id"),
            "plugin_name": plugin.get("name", "Unknown plugin"),
            "family": plugin.get("family", ""),
            "cves": plugin.get("cve", []) or [],
            "severity": f.get("severity", "info"),
            "severity_rank": SEV_RANK.get(f.get("severity", "info"), 0),
            "vpr": vpr_score,
            "epss": plugin.get("epss_score"),
            "on_cisa_kev": kev,
            "exploit_available": exploit_available,
            "exploited_by_malware": exploited,
            "in_the_news": in_news,
            "has_patch": bool(plugin.get("has_patch", False)),
            "unsupported_by_vendor": bool(plugin.get("unsupported_by_vendor", False)),
            "actively_dangerous": actively_dangerous,
            "first_found": f.get("first_found"),
            "last_fixed": f.get("last_fixed"),
            "last_found": f.get("last_found"),
            "held_days": held_days,
            "output": (f.get("output") or "").strip(),
        })
    return rows


def _same_window(rows, key_fn, window_hours=24):
    groups = defaultdict(list)
    for r in rows:
        groups[key_fn(r)].append(r)
    clusters = []
    for key, items in groups.items():
        items = [i for i in items if _parse(i["last_found"])]
        items.sort(key=lambda r: _parse(r["last_found"]))
        current, anchor = [], None
        for r in items:
            t = _parse(r["last_found"])
            if anchor is None or (t - anchor).total_seconds() <= window_hours * 3600:
                current.append(r)
                anchor = anchor or t
            else:
                clusters.append((key, current))
                current, anchor = [r], t
        if current:
            clusters.append((key, current))
    return clusters


def infer_causes(rows: list) -> list:
    insights = []

    # 0. Priority: resurfaced AND actively dangerous (KEV / exploitable / in wild).
    dangerous = [r for r in rows if r["actively_dangerous"]]
    if dangerous:
        kev_n = sum(1 for r in dangerous if r["on_cisa_kev"])
        wild_n = sum(1 for r in dangerous if r["exploited_by_malware"] or r["in_the_news"])
        insights.append({
            "kind": "threat_priority",
            "severity_rank": 5,  # always top
            "title": f"{len(dangerous)} resurfaced finding(s) are actively dangerous",
            "detail": ("These came back AND carry real-world exploit signals"
                       + (f" -- {kev_n} on the CISA KEV list" if kev_n else "")
                       + (f", {wild_n} exploited in the wild / in the news" if wild_n else "")
                       + ". Regardless of why they resurfaced, these are the ones to "
                         "remediate first."),
            "recommendation": ("Treat these as active incidents, not scan noise. "
                               "Verify the fix on each host now."),
            "evidence": {"count": len(dangerous),
                         "hosts": len({r["asset_id"] for r in dangerous}),
                         "cves": sorted({c for r in dangerous for c in r["cves"]})[:6]},
        })

    # 1. Asset-level bursts -> host rebuilt / restored.
    for asset_id, cluster in _same_window(rows, lambda r: r["asset_id"]):
        if len(cluster) >= 4:
            host = cluster[0]["hostname"]
            for r in cluster:
                r["reason"] = "asset_rebuild"
            insights.append({
                "kind": "asset_rebuild",
                "severity_rank": max(r["severity_rank"] for r in cluster),
                "title": f"{len(cluster)} findings resurfaced together on {host}",
                "detail": ("Multiple unrelated findings returned within the same "
                           "window -- almost always a host rebuilt, reimaged, or "
                           "restored from a snapshot taken before the fixes applied."),
                "recommendation": ("Confirm the last build/restore time for this host "
                                   "and rebase its golden image so it ships patched."),
                "evidence": {"host": host, "when": cluster[0]["last_found"],
                             "count": len(cluster),
                             "plugins": sorted({r["plugin_name"] for r in cluster})},
            })

    # 2. Plugin-level fleet regressions.
    for plugin_id, cluster in _same_window(rows, lambda r: r["plugin_id"]):
        assets = {r["asset_id"] for r in cluster}
        if len(assets) >= 5:
            name = cluster[0]["plugin_name"]
            for r in cluster:
                r.setdefault("reason", "fleet_regression")
            insights.append({
                "kind": "fleet_regression",
                "severity_rank": max(r["severity_rank"] for r in cluster),
                "title": f"'{name}' resurfaced on {len(assets)} hosts at once",
                "detail": ("The same finding returned across many hosts in one window: "
                           "a rolled-back superseding patch, a config-management change "
                           "reverting the fix, or a shared base image regressing."),
                "recommendation": ("Check patch-approval and config-management change "
                                   "history around this timestamp; one upstream change "
                                   "usually explains the whole set."),
                "evidence": {"plugin": name, "hosts": len(assets),
                             "when": cluster[0]["last_found"],
                             "cves": sorted({c for r in cluster for c in r["cves"]})},
            })

    # 3. Environment concentration (only if Axonius enrichment ran).
    enriched = [r for r in rows if r.get("environment")]
    if enriched:
        by_env = defaultdict(int)
        for r in enriched:
            by_env[r["environment"]] += 1
        top_env, top_n = max(by_env.items(), key=lambda kv: kv[1])
        if len(by_env) > 1 and top_n >= max(4, 0.5 * len(enriched)):
            insights.append({
                "kind": "environment_cluster",
                "severity_rank": 3,
                "title": f"{top_n} of {len(enriched)} resurfaced findings are in {top_env}",
                "detail": ("Resurfacing is concentrated in a single environment / "
                           "location. That points to a site-scoped event -- a rebuild "
                           "wave, a local config-management divergence, or a scanner or "
                           "credential change specific to that site."),
                "recommendation": (f"Review recent change activity in {top_env} before "
                                   "chasing findings host by host."),
                "evidence": {"environment": top_env, "count": top_n,
                             "breakdown": dict(sorted(by_env.items(),
                                                      key=lambda kv: -kv[1]))},
            })

    # 4. Flapping.
    flapping = [r for r in rows if r["held_days"] is not None
                and r["held_days"] <= 3 and not r.get("reason")]
    for r in flapping:
        r["reason"] = "scan_flap"
    if flapping:
        insights.append({
            "kind": "scan_flap",
            "severity_rank": max(r["severity_rank"] for r in flapping),
            "title": f"{len(flapping)} finding(s) resurfaced within 3 days of being fixed",
            "detail": ("A fix that reverts almost immediately is often not a real "
                       "regression. It commonly reflects scan inconsistency: a "
                       "credentialed scan seeing what an uncredentialed one missed, "
                       "intermittent reachability, or two scanners disagreeing."),
            "recommendation": ("Compare scan policy, credentials, and coverage between "
                               "the FIXED and REOPENED observations before treating "
                               "these as true regressions."),
            "evidence": {"items": [{"host": r["hostname"], "plugin": r["plugin_name"],
                                    "held_days": r["held_days"]} for r in flapping]},
        })

    # 5. Genuine long-dormant regressions.
    dormant = [r for r in rows if r["held_days"] is not None
               and r["held_days"] >= 60 and not r.get("reason")]
    for r in dormant:
        r["reason"] = "true_regression"
    if dormant:
        insights.append({
            "kind": "true_regression",
            "severity_rank": max(r["severity_rank"] for r in dormant),
            "title": f"{len(dormant)} finding(s) returned after being fixed for months",
            "detail": ("A fix that held for a long time and then broke is most likely a "
                       "genuine regression: a redeploy, dependency pin, or rollback "
                       "reintroduced the vulnerable component."),
            "recommendation": ("Treat these as real. Trace the specific artifact in the "
                               "plugin output back to the change that shipped it."),
            "evidence": {"items": [{"host": r["hostname"], "plugin": r["plugin_name"],
                                    "held_days": r["held_days"]} for r in dormant]},
        })

    for r in rows:
        r.setdefault("reason", "uncategorized")

    insights.sort(key=lambda i: (i["severity_rank"],
                                 i["evidence"].get("count",
                                 i["evidence"].get("hosts", 0))), reverse=True)
    return insights


REASON_LABELS = {
    "asset_rebuild": "Host rebuilt / restored",
    "fleet_regression": "Fleet-wide regression",
    "scan_flap": "Scan inconsistency",
    "true_regression": "Genuine regression",
    "uncategorized": "Needs review",
}


def risk_score(r):
    """A simple ranking score so the most urgent resurfaced findings float up."""
    score = r["severity_rank"] * 10
    if r["on_cisa_kev"]:
        score += 40
    if r["exploited_by_malware"] or r["in_the_news"]:
        score += 25
    if r["exploit_available"]:
        score += 15
    if isinstance(r["epss"], (int, float)):
        score += r["epss"] * 20
    if isinstance(r["vpr"], (int, float)):
        score += r["vpr"]
    return score


def summarize(rows: list, insights: list) -> dict:
    return {
        "total": len(rows),
        "assets": len({r["asset_id"] for r in rows}),
        "plugins": len({r["plugin_id"] for r in rows}),
        "critical": sum(1 for r in rows if r["severity"] == "critical"),
        "high": sum(1 for r in rows if r["severity"] == "high"),
        "kev": sum(1 for r in rows if r["on_cisa_kev"]),
        "exploitable": sum(1 for r in rows if r["actively_dangerous"]),
        "environments": len({r["environment"] for r in rows if r.get("environment")}),
        "insights": len(insights),
        "reason_labels": REASON_LABELS,
    }
